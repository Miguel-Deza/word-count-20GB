package main

import (
	"fmt"
	"os"
	"runtime"
	"strings"
	"sync"
	"time"
)

const fileName = "larger.txt"

func main() {
	// calculate the time
	startTime := time.Now()
	totalWordHashMap := make(map[string]int)

	numWorkers := runtime.NumCPU()
	var wg sync.WaitGroup

	interimResultFromWorkers := make(chan map[string]int)

	fileInfo, err := os.Stat(fileName)
	if err != nil {
		panic("Error getting file info")
	}
	fileSize := fileInfo.Size()
	chunkSize := fileSize / int64(numWorkers)

	fmt.Printf("\nfile info: size %v\n", fileSize)

	for i := 0; i < numWorkers; i++ {
		wg.Add(1)
		start := int64(i) * chunkSize
		var end int64
		if i == numWorkers-1 {
			end = fileSize
		} else {
			end = start + chunkSize
		}
		go readFileFromCertainChunk(fileName, start, end, interimResultFromWorkers, &wg)
	}

	// create goroutine to close channel when all workers are finish
	go func() {
		wg.Wait()
		// end time
		elapsedTime := time.Since(startTime).Milliseconds()
		println("Time elapsed in milliseconds: ", elapsedTime)
		close(interimResultFromWorkers)
	}()

	for result := range interimResultFromWorkers {
		for key, value := range result {
			totalWordHashMap[key] += value
		}
	}

	WriteResultsToFile(totalWordHashMap)
}

func readFileFromCertainChunk(fileName string, start, end int64, result chan<- map[string]int, wg *sync.WaitGroup) {
	defer wg.Done()

	file, err := os.Open(fileName)
	if err != nil {
		panic("Error opening file")
	}
	defer file.Close()

	file.Seek(start, 0)
	buffer := make([]byte, end-start)
	_, err = file.Read(buffer)
	if err != nil {
		panic("Error reading file")
	}

	words := string(buffer)
	fruits := "manzanas bananas naranjas peras uvas kiwis sandias melones mangos fresas frambuesas papayas limones cerezas moras aguacates cocos"
	fruitList := strings.Fields(fruits)

	wordCount := make(map[string]int)
	for _, fruit := range fruitList {
		wordCount[fruit] = countWord(words, fruit)
	}

	result <- wordCount
}

func countWord(words, word string) int {
	return strings.Count(words, word)
}

func WriteResultsToFile(resultMap map[string]int) {
	file, err := os.Create("resultados.txt")
	if err != nil {
		panic("Error creating file")
	}
	defer file.Close()

	for fruit, count := range resultMap {
		_, err := fmt.Fprintf(file, "%s: %d\n", fruit, count)
		if err != nil {
			panic("Error writing to file")
		}
	}
}
